=== Social Sidebar ===
Contributors: thomasdavis
Donate link: http://thomasalwyndavis.com/
Tags: social, sidebar, facebook, twitter, linkedin, thomas, social networking, widget, , plugin,page,google
Requires at least: 2.0.2
Tested up to: 3.0.1
Stable tag: Trunk

A popout menu for your website, simple to install and setup, shows social networking icons in a un-obtrusive way.

== Description ==

Update: If you had trouble installing the plugin, please download the plugin zip from <a href="http://thomasalwyndavis.com/2010/09/socialsidebar-wordpress-plugin/">here</a>

The plugin is custimizable and lets you change the icons if you have fancier ones.

For a more details and a screenshot view the site below

<a href="http://thomasalwyndavis.com/2010/09/socialsidebar-wordpress-plugin/">Plugin Site</a>

An example of the plugin is on the right hand side of the page.

== Installation ==

1) Using wordpress plugin installer simply upload the zip

2) Active plugin and find the 'Social Sidebar' menu under the Settings panel.

3) Input in either of the fields and specify custom images otherwise the defaults will be used

4) Your done! Send me a message from my <a href="http://thomasalwyndavis.com">blog</a> and I will showcase your site using it on my blog

== Frequently Asked Questions ==

If you have any questions, ask them on <a href="http://thomasalwyndavis.com">my blog</a>. Also if you want features come talk to me and I will add them in.

Here are some demo sites to view
http://www.studioicd.com/interior/

== Screenshots ==

1. What the plugin looks like once installed on your blog or website

== Changelog ==

= 1.0 =
* First Version, no changes just yet

= 2.0 =
* Support for more widgets and other fixes



`<?php code(); // goes in backticks ?>`